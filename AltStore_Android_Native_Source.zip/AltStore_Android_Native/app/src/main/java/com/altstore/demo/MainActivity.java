package com.altstore.demo;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(9,8,17), PANEL=Color.rgb(22,19,33), MUTED=Color.rgb(164,154,184), PURPLE=Color.rgb(187,151,255), WHITE=Color.rgb(249,246,255);
    LinearLayout root, body, cards, nav;
    EditText search;
    String category="Все", screen="home";
    Set<String> fav=new LinkedHashSet<>(), library=new LinkedHashSet<>();
    ArrayList<AppItem> items=new ArrayList<>();
    static class AppItem {String id,name,dev,cat,icon,desc; int color; String rating,size,version;
      AppItem(String i,String n,String d,String c,String ic,String de,int co,String r,String s,String v){id=i;name=n;dev=d;cat=c;icon=ic;desc=de;color=co;rating=r;size=s;version=v;}
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(0);
      seed(); build(); render();}
    void seed(){
      items.add(new AppItem("nova","Nova Launcher","Nova Labs","Утилиты","✦","Персонализируй главный экран, настрой сетку, жесты и оформление.",0xff8154dd,"4.9","18.4 MB","8.2.1"));
      items.add(new AppItem("orbit","Orbit Runner","Northstar Studio","Игры","◈","Неоновая аркада с космическими трассами и атмосферным саундтреком.",0xff397fc9,"4.8","146 MB","2.4.0"));
      items.add(new AppItem("pixel","Pixel Studio","Tiny Frame","Творчество","▦","Мастерская пиксель-арта, палитр и небольших анимаций.",0xffdc71b6,"4.7","42 MB","1.8.3"));
      items.add(new AppItem("focus","Focus Flow","Still Works","Продуктивность","◉","Планируй задачи и сессии концентрации в спокойном пространстве.",0xff39a88b,"4.8","26 MB","3.1.2"));
      items.add(new AppItem("echo","Echo Player","Echo Collective","Медиа","♫","Музыкальный концепт-плеер с коллекциями по настроению.",0xff7953c5,"4.6","31 MB","1.5.0"));
      items.add(new AppItem("vault","Pocket Vault","Alt Labs","Утилиты","⬡","Концепт личного хранилища заметок и быстрых ссылок.",0xffd49c43,"4.5","12 MB","0.9.6"));
      items.add(new AppItem("bloom","Bloom Notes","Soft Signal","Продуктивность","✿","Заметки, идеи и списки в мягком визуальном стиле.",0xffd95aa9,"4.7","21 MB","2.0.1"));
      items.add(new AppItem("shader","Shader Lab","Visual Dept.","Творчество","◌","Интерактивная лаборатория цвета, форм и абстрактных композиций.",0xff4a83d1,"4.6","36 MB","1.2.0"));
    }
    GradientDrawable shape(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(stroke!=0)d.setStroke(1,stroke);return d;}
    TextView text(String t,int size,int color,boolean bold){TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(color);v.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));return v;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int a,int b,int c,int d){v.setPadding(a,b,c,d);}
    TextView button(String label,Runnable action){TextView v=text(label,13,WHITE,true);v.setGravity(Gravity.CENTER);v.setPadding(14,12,14,12);v.setBackground(shape(0xff272137,14,0xff403450));v.setOnClickListener(w->action.run());return v;}
    void build(){
      root=column();root.setBackgroundColor(BG);setContentView(root);
      LinearLayout top=row();top.setPadding(20,15,20,14);top.setGravity(Gravity.CENTER_VERTICAL);
      TextView logo=text("A✦",21,0xff1b1027,true);logo.setGravity(Gravity.CENTER);logo.setBackground(shape(0xffc3a1ff,14,0));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(44,44);top.addView(logo,lp);
      LinearLayout brand=column();pad(brand,12,0,0,0);brand.addView(text("ALTSTORE",14,WHITE,true));brand.addView(text("D I S C O V E R   M O R E",8,MUTED,false));top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
      TextView profile=button("R",()->{screen="profile";render();});top.addView(profile);root.addView(top);
      ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);body=column();body.setPadding(18,8,18,24);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
      nav=row();nav.setPadding(8,8,8,8);nav.setBackgroundColor(0xff11101a);
      String[] labels={"⌂  Обзор","▦  Каталог","♡  Библиотека"};
      String[] ids={"home","catalog","library"};
      for(int i=0;i<labels.length;i++){final String id=ids[i];TextView b=text(labels[i],12,WHITE,true);b.setGravity(Gravity.CENTER);b.setPadding(3,13,3,13);b.setOnClickListener(v->{screen=id;render();});nav.addView(b,new LinearLayout.LayoutParams(0,-2,1));}
      root.addView(nav);
    }
    void render(){
      body.removeAllViews();
      if(screen.equals("profile")){profilePage();return;}
      if(screen.equals("home")){
        LinearLayout hero=column();hero.setPadding(23,25,20,25);hero.setBackground(shape(0xff20162f,24,0xff45305f));
        hero.addView(text("✦  ВЫБОР РЕДАКЦИИ",10,0xffd4baff,true));addSpace(hero,20);
        hero.addView(text("ТВОЙ СЛЕДУЮЩИЙ",11,0xffc9b7e9,true));TextView h=text("Discover\\nmore.",45,WHITE,true);h.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));hero.addView(h);
        addSpace(hero,7);hero.addView(text("Приложения, которые меняют привычное.",12,MUTED,false));addSpace(hero,18);
        TextView explore=button("Открыть подборку   ↗",()->{screen="catalog";render();});explore.setBackground(shape(0xffc0a0ff,14,0));explore.setTextColor(0xff1a1024);hero.addView(explore);body.addView(hero);
        addSpace(body,25);
      }
      if(screen.equals("library"))body.addView(text("МОЯ КОЛЛЕКЦИЯ",10,PURPLE,true));
      else body.addView(text(screen.equals("catalog")?"EXPLORE THE CATALOG":"CURATED FOR YOU",10,PURPLE,true));
      addSpace(body,6);body.addView(text(screen.equals("library")?"Моя библиотека ✳":screen.equals("catalog")?"Исследуй каталог ✳":"Находки недели ✳",27,WHITE,true));addSpace(body,15);
      search=new EditText(this);search.setSingleLine(true);search.setTextColor(WHITE);search.setHintTextColor(MUTED);search.setHint("⌕  Найти приложение…");search.setTextSize(13);search.setPadding(15,4,15,4);search.setBackground(shape(0xff171521,14,0xff302a3c));body.addView(search,new LinearLayout.LayoutParams(-1,49));addSpace(body,13);
      HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);LinearLayout chips=row();
      for(String c:new String[]{"Все","Игры","Утилиты","Творчество","Продуктивность","Медиа"}){TextView ch=button(c,()->{category=c;render();});LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-2);cp.setMargins(0,0,8,0);chips.addView(ch,cp);if(c.equals(category))ch.setBackground(shape(0xff40305c,30,0xff9f7be2));}
      hsv.addView(chips);body.addView(hsv);addSpace(body,14);
      LinearLayout list=column();body.addView(list);
      Runnable fill=()->{list.removeAllViews();String q=search.getText().toString().toLowerCase(Locale.ROOT);int shown=0;
        for(AppItem a:items){if(!category.equals("Все")&&!a.cat.equals(category))continue;if(!q.isEmpty()&&!(a.name+" "+a.dev+" "+a.cat).toLowerCase(Locale.ROOT).contains(q))continue;if(screen.equals("library")&&!fav.contains(a.id)&&!library.contains(a.id))continue;
          list.addView(appCard(a));addSpace(list,11);shown++;}
        if(shown==0)list.addView(text("Здесь пока пусто — попробуй другой фильтр.",13,MUTED,false));
      };fill.run();search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){fill.run();}public void afterTextChanged(Editable e){}});
      addSpace(body,20);TextView note=text("ALTSTORE CONCEPT  •  BUILD 0.9.6",9,0xff716980,false);note.setGravity(Gravity.CENTER);body.addView(note);
    }
    View appCard(AppItem a){
      LinearLayout card=column();card.setPadding(15,15,15,15);card.setBackground(shape(PANEL,20,0xff302a3c));
      LinearLayout top=row();TextView icon=text(a.icon,27,WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(a.color,17,0));top.addView(icon,new LinearLayout.LayoutParams(58,58));
      LinearLayout name=column();pad(name,13,0,0,0);name.addView(text(a.name,16,WHITE,true));name.addView(text(a.dev,11,MUTED,false));top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
      TextView heart=text(fav.contains(a.id)?"♥":"♡",22,fav.contains(a.id)?0xffff8edc:MUTED,true);heart.setOnClickListener(v->{if(fav.contains(a.id))fav.remove(a.id);else fav.add(a.id);render();});top.addView(heart);card.addView(top);
      addSpace(card,12);card.addView(text(a.desc,12,0xffb3a9c3,false));addSpace(card,12);
      LinearLayout bottom=row();bottom.addView(text("★ "+a.rating+"  ·  DEMO",10,0xffffd18b,true),new LinearLayout.LayoutParams(0,-2,1));bottom.addView(text(a.cat,10,0xffc4a6ff,true));card.addView(bottom);
      card.setOnClickListener(v->details(a));return card;
    }
    void details(AppItem a){
      Dialog d=new Dialog(this);LinearLayout box=column();box.setPadding(22,22,22,22);box.setBackground(shape(0xff151320,24,0xff4b3b61));
      LinearLayout top=row();TextView icon=text(a.icon,36,WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(shape(a.color,20,0));top.addView(icon,new LinearLayout.LayoutParams(76,76));LinearLayout n=column();pad(n,15,0,0,0);n.addView(text(a.name,23,WHITE,true));n.addView(text(a.dev,12,MUTED,false));n.addView(text("★ "+a.rating+"   "+a.cat,10,PURPLE,true));top.addView(n);box.addView(top);
      addSpace(box,22);box.addView(text("APPLICATION PREVIEW  ·  DEMO DATA",9,PURPLE,true));addSpace(box,8);box.addView(text(a.desc,14,0xffc3bbd0,false));addSpace(box,15);
      LinearLayout info=row();info.addView(text("Версия\\n"+a.version,11,MUTED,false),new LinearLayout.LayoutParams(0,-2,1));info.addView(text("Размер\\n"+a.size,11,MUTED,false),new LinearLayout.LayoutParams(0,-2,1));box.addView(info);addSpace(box,20);
      TextView get=button(library.contains(a.id)?"Открыть демо ✓":"Получить · DEMO ↓",()->{library.add(a.id);new AlertDialog.Builder(this).setTitle("Демо завершено").setMessage("Это визуальная демонстрация. Реальная загрузка и установка APK не выполнялись.").setPositiveButton("Понятно",null).show();d.dismiss();});get.setBackground(shape(0xffc0a0ff,14,0));get.setTextColor(0xff1a1024);box.addView(get);addSpace(box,8);
      box.addView(button(fav.contains(a.id)?"♥ В избранном":"♡ Добавить в избранное",()->{if(fav.contains(a.id))fav.remove(a.id);else fav.add(a.id);d.dismiss();render();}));addSpace(box,8);box.addView(button("Закрыть",d::dismiss));
      ScrollView sv=new ScrollView(this);sv.addView(box);d.setContentView(sv);Window w=d.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.92),-2);}d.show();if(d.getWindow()!=null)d.getWindow().setLayout((int)(getResources().getDisplayMetrics().widthPixels*.92),-2);
    }
    void profilePage(){body.addView(text("LOCAL DEMO PROFILE",10,PURPLE,true));addSpace(body,12);body.addView(text("Alt Explorer",30,WHITE,true));addSpace(body,8);body.addView(text("Твой личный уголок в AltStore.",13,MUTED,false));addSpace(body,22);body.addView(text("ИЗБРАННОЕ     "+fav.size(),14,WHITE,true));addSpace(body,12);body.addView(text("В БИБЛИОТЕКЕ     "+library.size(),14,WHITE,true));addSpace(body,25);body.addView(text("Версия приложения     0.9.6 concept",12,MUTED,false));addSpace(body,12);body.addView(button("Сбросить локальные данные",()->{fav.clear();library.clear();render();}));}
    void addSpace(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,h));}
}